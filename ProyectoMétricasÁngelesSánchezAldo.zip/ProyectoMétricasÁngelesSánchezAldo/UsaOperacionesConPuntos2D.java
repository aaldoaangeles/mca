/**
 *  Programa que muestra el uso de las clases
 *  Punto2D y OperacionesConPuntos2D
 *
 *  Actividad a realizar:
 *  1.- Pedir los datos en enorno gráfico
 *  2.- Probar los métodos de OperacionesConPuntos2D
 *
 *   @version 22/Sep/22
 *
 * @author Ángeles Sánchez Aldo Javier 320286144
 * Matemáticas para las ciencias aplicadas
 */

package Metricas1;

import javax.swing.*;

public class UsaOperacionesConPuntos2D {

    public static void main(String... something){

        String[] arreglo = {"Norma","Metrica Euclidiana","Metrica Manhattan", "Punto Producto", "Area entre dos puntos y el origen"};
        int inicio = JOptionPane.showOptionDialog(null, "¿Qué opreación deseas realizar?", "Operaciones con puntos", 0,JOptionPane.QUESTION_MESSAGE, null, arreglo, "Norma");
        if (inicio == 0){

            double xa = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada x del punto A"));
            double ya = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada y del punto A"));

            Punto2D a = new Punto2D(xa,ya);

            double norma = OperacionesConPuntos2D.norma(a);
            JOptionPane.showMessageDialog(null, "La norma de " + a + " es : " + norma);

        }
        if(inicio == 1) {
            double xa = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada x del punto A"));
            double ya = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada y del punto A"));
            double xb = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada x del punto B"));
            double yb = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada y del punto B"));

            Punto2D a = new Punto2D(xa, ya);
            Punto2D b = new Punto2D(xb, yb);

            double mEuclidiana = OperacionesConPuntos2D.metricaEuclidiana(a, b);
            JOptionPane.showMessageDialog(null,"La métrica Euclidiana de " + a + " y " +b+" es: " + mEuclidiana );
          //  System.out.println("La métrica Euclidiana de " + a + " es: " + mEuclidiana);

        }

        if (inicio == 2){
            double xa = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada x del punto A"));
            double ya = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada y del punto A"));
            double xb = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada x del punto B"));
            double yb = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada y del punto B"));

            Punto2D a = new Punto2D(xa, ya);
            Punto2D b = new Punto2D(xb, yb);

            double mTaxista = OperacionesConPuntos2D.metricaTaxista(a, b);
            JOptionPane.showMessageDialog(null,"La métrica del Taxista de " + a + " y "+b+" es: " + mTaxista );

        }
        if (inicio == 3){
            double xa = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada x del punto A"));
            double ya = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada y del punto A"));
            double xb = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada x del punto B"));
            double yb = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada y del punto B"));

            Punto2D a = new Punto2D(xa, ya);
            Punto2D b = new Punto2D(xb, yb);

            double pPunto = OperacionesConPuntos2D.dotProduct(a, b);
            JOptionPane.showMessageDialog(null, "El producto punto de " + a + " y "+b+" es: " + pPunto );

        }
        if(inicio == 4){
            double xa = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada x del punto A"));
            double ya = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada y del punto A"));
            double xb = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada x del punto B"));
            double yb = Double.parseDouble(JOptionPane.showInputDialog("Digite la coordenada y del punto B"));

            Punto2D a = new Punto2D(xa, ya);
            Punto2D b = new Punto2D(xb, yb);
            Punto2D c = new Punto2D(0, 0);

            double areapntos = OperacionesConPuntos2D.area(a, b, c);
            JOptionPane.showMessageDialog(null,"El área de los puntos " +a+ " y " +b+ " respecto al origen es: " + areapntos );

        }



    }
}
